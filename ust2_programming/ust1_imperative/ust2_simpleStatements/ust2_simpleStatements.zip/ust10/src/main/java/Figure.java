interface Figure {

  double getPerimeter();

  double getArea();


}
