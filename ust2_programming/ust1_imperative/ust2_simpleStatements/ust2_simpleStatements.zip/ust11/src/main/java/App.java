class App {

  public static void main(String[] args) {
    FigureViewFactory figureViewFactory = new FigureViewFactory();
    Figure[] figures = new Figure[5];
    for (int i = 0; i < figures.length; i++) {
      figures[i] = figureViewFactory.create().read();
    }
    double perimeters = 0;
    double areas = 0;
    for (Figure figure : figures) {
      figureViewFactory.getFigureView(figure).writeln();
      perimeters += figure.getPerimeter();
      areas += figure.getArea();
    }
    new Console().writeln("El total de perímetros es " + perimeters
        + " y el de áreas es " + areas);
  }


}


otra versón: inversión de dependencias
otra versió: partón prototipo

doo, nuevos apartados
- relacion es un, bien?!?!
repetir herencia por limitación y bertran meyer
herencia rechazada
patrón método plantilla
ley estricat de demeter
- Reusabilidad
vs parametrización
vs composición
- Flexibildad
liskov
delegación
doble despacho
- ocultación de información
interfaces vs clases abstractas
principio de segregación de interfaces
meter citas de jacobson, 
principio de inversión de dependencias para romper ciclo!!!

- revisar agilismo : factoría vs inyección?!?!

!!! Repetir relaciones en diseño modular!!!!!! 
buscar cita booch: jeraquía de composición con elmentos de clasificación y asociaciones


